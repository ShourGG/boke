# Koi Blog - 个人博客系统

一个功能完整的个人博客系统，支持文章发布和网站收录功能，专为宝塔面板部署优化。

## ✨ 特性

### 🎯 核心功能
- **博客系统**：文章发布、分类管理、标签系统
- **网站收录**：网站目录功能，支持分类和搜索
- **响应式设计**：完美支持桌面和移动设备
- **SEO优化**：友好的URL结构和元数据管理
- **评论系统**：支持文章评论（可扩展）

### 🛡️ 安全特性
- PDO预处理语句防SQL注入
- XSS防护和CSRF保护
- 文件上传安全验证
- 管理员权限控制

### 🎨 用户体验
- 现代化的Bootstrap 5界面
- 直观的管理后台
- 一键安装向导
- 图片懒加载和性能优化

## 🚀 快速开始

### 环境要求
- PHP >= 7.4
- MySQL >= 5.7
- Apache/Nginx (推荐Apache)
- PDO和PDO_MySQL扩展

### 宝塔面板部署步骤

1. **下载源码**
   ```bash
   # 将所有文件上传到网站根目录
   ```

2. **设置权限**
   - 确保 `config/` 和 `uploads/` 目录可写
   - 在宝塔面板中设置目录权限为 755

3. **创建数据库**
   - 在宝塔面板创建MySQL数据库
   - 记录数据库名、用户名和密码

4. **运行安装向导**
   - 访问 `http://你的域名/install.php`
   - 按照向导完成安装
   - 删除 `install.php` 文件

5. **配置完成**
   - 访问 `http://你的域名/admin` 进入管理后台
   - 开始发布内容

## 📁 项目结构

```
koi-blog/
├── app/                    # 应用核心
│   ├── controllers/        # 控制器
│   ├── models/            # 数据模型
│   ├── views/             # 视图模板
│   └── core/              # 核心类库
├── config/                # 配置文件
├── public/                # 静态资源
│   ├── css/              # 样式文件
│   ├── js/               # JavaScript文件
│   └── images/           # 图片资源
├── uploads/               # 上传文件目录
├── database.sql          # 数据库结构
├── install.php           # 安装向导
├── index.php             # 入口文件
├── .htaccess             # Apache配置
└── README.md             # 说明文档
```

## 🎛️ 管理功能

### 文章管理
- ✅ 文章增删改查
- ✅ 分类和标签管理
- ✅ 富文本编辑器
- ✅ 图片上传功能
- ✅ SEO设置

### 网站收录管理
- ✅ 网站添加和审核
- ✅ 分类管理
- ✅ 点击统计
- ✅ 批量操作

### 系统设置
- ✅ 网站基本信息
- ✅ 管理员账户管理
- ✅ 系统统计面板

## 🔧 技术栈

- **后端**：PHP 7.4+ (原生MVC架构)
- **数据库**：MySQL 5.7+
- **前端**：Bootstrap 5 + jQuery
- **图标**：Font Awesome 6
- **编辑器**：支持富文本编辑

## 📊 数据库设计

### 核心表结构
- `posts` - 文章表
- `categories` - 分类表
- `tags` - 标签表
- `post_tags` - 文章标签关联表
- `websites` - 网站收录表
- `website_categories` - 网站分类表
- `comments` - 评论表
- `admins` - 管理员表

## 🛠️ 自定义配置

### 修改网站信息
编辑 `config/config.php` 文件：
```php
define('SITE_NAME', '你的网站名称');
define('SITE_DESCRIPTION', '网站描述');
define('SITE_URL', 'http://你的域名');
```

### 上传限制
```php
define('UPLOAD_MAX_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', 'jpg,jpeg,png,gif,pdf,doc,docx');
```

### 分页设置
```php
define('POSTS_PER_PAGE', 10);
define('WEBSITES_PER_PAGE', 20);
```

## 🔒 安全建议

1. **删除安装文件**：安装完成后立即删除 `install.php`
2. **定期备份**：定期备份数据库和上传文件
3. **更新密码**：使用强密码并定期更换
4. **文件权限**：确保敏感文件权限设置正确
5. **HTTPS**：生产环境建议启用HTTPS

## 🐛 故障排除

### 常见问题

**1. 404错误**
- 检查 `.htaccess` 文件是否存在
- 确认Apache已启用mod_rewrite模块

**2. 数据库连接失败**
- 检查数据库配置信息
- 确认数据库服务正常运行

**3. 文件上传失败**
- 检查 `uploads/` 目录权限
- 确认PHP上传限制设置

**4. 样式丢失**
- 检查 `public/` 目录权限
- 确认CDN资源可正常访问

## 📝 更新日志

### v1.0.0 (2024-01-22)
- ✅ 完整的MVC架构
- ✅ 博客和网站收录功能
- ✅ 响应式管理后台
- ✅ 一键安装向导
- ✅ SEO优化和安全防护

## 🤝 贡献

欢迎提交Issue和Pull Request来帮助改进项目！

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 💬 支持

如果您在使用过程中遇到问题，可以：

1. 查看本文档的故障排除部分
2. 提交 GitHub Issue
3. 发送邮件至项目维护者

---

**Koi Blog** - 让写作和分享变得简单 🐟
